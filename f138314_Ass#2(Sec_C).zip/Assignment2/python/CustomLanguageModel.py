import math, collections
class CustomLanguageModel:

  def __init__(self, corpus):
    """Initialize your data structures in the constructor."""
    # TODO your code here
    self.U_Count = collections.defaultdict(lambda: 0)
    self.B_Count = collections.defaultdict(lambda: 0)
    self.T_Count = collections.defaultdict(lambda: 0)
    self.totals = 0 
    self.train(corpus)
    
  def train(self, corpus):
    """ Takes a corpus and trains your language model. 
        Compute any counts or other corpus statistics in this function.
    """  
    # TODO your code here
    b_List = []
    t_List = []
    for sentence in corpus.corpus:
      for i in range(len(sentence.data)):
        word = sentence.data[i].word
        self.totals += 1

        
        self.U_Count[word] = self.U_Count[word] + 1

        
        if word != '</s>':
          b_List.append(word)
          b_List.append(sentence.data[i + 1].word)
          self.B_Count[tuple(b_List)] = self.B_Count[tuple(b_List)] + 1
          del b_List[:]

        
        if i + 2 < len(sentence):
          t_List.append(word)
          t_List.append(sentence.data[i + 1].word)
          t_List.append(sentence.data[i + 2].word)
          self.T_Count[tuple(t_List)] = self.T_Count[tuple(t_List)] + 1
          del t_List[:]

    pass

  def score(self, sentence):
    """ Takes a list of strings as argument and returns the log-probability of the 
        sentence using your language model. Use whatever data you computed in train() here.
    """
    # TODO your code here
    score = 0.0

    for i in range(len(sentence)):
     
      if i > 1:
        triagramlist = [sentence[i - 2], sentence[i - 1], sentence[i]]
        if self.T_Count[tuple(triagramlist)] != 0:
          triagramProb = math.log(float(self.T_Count[tuple(triagramlist)]) /
                           self.B_Count[tuple([sentence[i - 2], sentence[i - 1]])])
          score += triagramProb
          continue

    
      if i > 0:
        biagramlist = [sentence[i - 1], sentence[i]]
        if self.B_Count[tuple(biagramlist)] != 0:
          biagramProb = math.log(float(self.B_Count[tuple(biagramlist)]) /
                                 self.U_Count[sentence[i - 1]])
          score += biagramProb

        
        else:
          unigramProb = math.log(float(self.U_Count[sentence[i]] + 1) /
                                           (self.totals + len(self.U_Count)))
          score += unigramProb

      else: 
        score += math.log(0.9) + math.log(float(self.U_Count[sentence[i]] + 1) /
                                           (self.totals + len(self.U_Count)))

    return score