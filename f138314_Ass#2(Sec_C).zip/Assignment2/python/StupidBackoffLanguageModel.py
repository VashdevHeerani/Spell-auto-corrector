import math, collections
class StupidBackoffLanguageModel:

  def __init__(self, corpus):
    """Initialize your data structures in the constructor."""
    # TODO your code here
    self.T_Count = collections.defaultdict(lambda: 0)
    self.B_Count = collections.defaultdict(lambda: 0)
    self.U_Count = collections.defaultdict(lambda: 0)
    self.total = 0
    self.train(corpus)

  def train(self, corpus):
    """ Takes a corpus and trains your language model. 
        Compute any counts or other corpus statistics in this function.
    """  
    # TODO your code here
    for sentence in corpus.corpus:
        datums = sentence.data
        for i in range(len(datums)):
            self.total += 1
            token = datums[i].word
            self.U_Count[token] += 1  #count of the word
            if i > 0:
                token_1 = datums[i - 1].word
                bi_key = token_1 + "," + token
                self.B_Count[bi_key] += 1  #count of the bigram
                if i > 1:
                    token_2 = datums[i - 2].word
                    tri_key = token_2 + "," + token_1 + "," + token
                    self.T_Count[tri_key] += 1 #count of the trigram
    pass

  def score(self, sentence):
    """ Takes a list of strings as argument and returns the log-probability of the 
        sentence using your language model. Use whatever data you computed in train() here.
    """
    # TODO your code here
    score = 0
    for i in range(len(sentence)):
        if i > 0:
            bi_key = sentence[i - 1] + "," + sentence[i]
            count_bigram = self.B_Count[bi_key]
            count_unigram = self.U_Count[sentence[i - 1]]
            if count_bigram > 0:
                score =score+ math.log(count_bigram)
                score =score- math.log(count_unigram)
            else:
                count_unigram = self.U_Count[sentence[i]]
                score =score+ math.log(count_unigram + 1)
                score =score+ math.log(0.4)
                score =score- math.log(self.total)
    return score
